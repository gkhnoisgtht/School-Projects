#include	<stdlib.h>
#include	<stdio.h>

extern	char	begin;
extern	char	end;

extern	void	enterBeginEnd	();
extern	void	printFromBeginToEnd	();
