#include "123header.h"

void	printFromBeginToEnd()
{
  char	i;

  for  (i = begin;  i <= end;  i++)
    printf("%d = %c\n",i,i);
}
