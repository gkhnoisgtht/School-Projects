#include "123header.h"

char	begin;
char	end;

int	main	()
{
  enterBeginEnd();
  printFromBeginToEnd();
  return(EXIT_SUCCESS);
}
