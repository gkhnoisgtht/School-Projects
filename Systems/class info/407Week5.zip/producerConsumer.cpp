#include        <stdlib.h>
#include        <stdio.h>
#include        <unistd.h>
#include        <pthread.h>
#include        "Unsafe_Buffer.h"
  
const int       NUM_INTEGERS_TO_BUFFER  = 0x1000;
    
void*   stuffIntegersIn (void*  vPtr)
{     
  for  (int i = 0;  i < NUM_INTEGERS_TO_BUFFER;  i++)
    ((Buffer*)vPtr)->putIn(i);
    
  return(NULL);
}   
    
void*   pullIntegersOut (void*  vPtr)
{
  for  (int i = 0;  i < NUM_INTEGERS_TO_BUFFER;  i++)
  {
    int j = ((Buffer*)vPtr)->pullOut();

    printf("Trial %d got %d.\n",i,j);
    //printf("Trial %d got %d%s.\n",
    //       i,j,(i==j) ? "" : " (UhOh)");
    fflush(stdout);
  }

  return(NULL);
}


int     main    ()
{
  pthread_t     producer0;
  pthread_t     producer1;
  pthread_t     consumer0;
  pthread_t     consumer1;
  Buffer        buffer;

  pthread_create(&producer0,NULL,stuffIntegersIn,&buffer);
  pthread_create(&producer1,NULL,stuffIntegersIn,&buffer);
  pthread_create(&consumer0,NULL,pullIntegersOut,&buffer);
  pthread_create(&consumer1,NULL,pullIntegersOut,&buffer);

  pthread_join(producer0,NULL);
  pthread_join(producer1,NULL);
  pthread_join(consumer0,NULL);
  pthread_join(consumer1,NULL);
  return(EXIT_SUCCESS);
}
