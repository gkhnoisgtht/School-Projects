#include	<stdlib.h>
#include	<stdio.h>
#include	<pthread.h>

const int	N	= 2;

int*	heapPtr;
int	data	= 2;

void*	threadRoutine	(void*	vPtr
			)
{
  int	increment	= *(int*)vPtr;

  data		+= increment;
  (*heapPtr)	+= increment;
  printf("data = %d\theap = %d\n",data,*heapPtr);
  return(NULL);
}


int	main	()
{
  pthread_t	one;
  pthread_t	two;
  int		pos1	= +1;
  int		neg1	= -1;
  heapPtr	= (int*)malloc(sizeof(int));
  pthread_create(&one,NULL,threadRoutine,&pos1);
  pthread_create(&two,NULL,threadRoutine,&neg1);

  pthread_join(one,NULL);
  pthread_join(two,NULL);

  printf("At end:\tdata = %d\theap = %d\n",data,*heapPtr);
  free(heapPtr);
  return(EXIT_SUCCESS);
}
