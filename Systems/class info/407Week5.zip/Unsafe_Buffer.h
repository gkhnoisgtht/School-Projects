class   Buffer
{
  enum { SIZE   = 3 };

  int   array_[SIZE];
  int   inIndex_;
  int   outIndex_;
  int   numItems_;
  pthread_mutex_t	lock;
  pthread_cond_t	notFullCond;
  pthread_cond_t	notEmptyCond;

public :

  Buffer        ()
  {
    inIndex_ = outIndex_
      = numItems_ = 0;
    pthread_mutex_init(&lock,NULL);
    pthread_cond_init(&notFullCond, NULL);
    pthread_cond_init(&notEmptyCond, NULL);
  }

  ~Buffer       ()
  {
    pthread_mutex_destroy(&lock);
    pthread_cond_destroy(&notFullCond);
    pthread_cond_destroy(&notEmptyCond);
  }


  int   getNumItems  () const
  { return(numItems_); }

  void  putIn (int    i)
  {
    pthread_mutex_lock(&lock);
    while  (getNumItems() >= SIZE)
    {
      printf("Full!  Waiting!\n");
      pthread_cond_wait(&notFullCond,&lock);
      usleep(10);
    }

    array_[inIndex_] = i;

    usleep(10);
    inIndex_++;
    numItems_++;
    if  (inIndex_ >= SIZE)
      inIndex_ = 0;
    pthread_mutex_unlock(&lock);
    pthread_cond_signal(&notEmptyCond);
  }

  int   pullOut ()
  {
    pthread_mutex_lock(&lock);
    while  (getNumItems() <= 0)
    {
      printf("Empty!  Waiting!\n");
      pthread_cond_wait(&notEmptyCond,&lock);
      usleep(10);
    }

    int toReturn        = array_[outIndex_];

    usleep(10);
    outIndex_++;
    numItems_--;
    if  (outIndex_ >= SIZE)
      outIndex_ = 0;

    pthread_cond_signal(&notFullCond);
    pthread_mutex_unlock(&lock);
    return(toReturn);
  }
};
