#include	<stdlib.h>
#include	<stdio.h>
#include	<signal.h>
#include	<string.h>

int	main	()
{
  // Set up struct to specify the new action.
  struct sigaction act;

  //  Set member vars to zero:
  memset(&act,'\0',sizeof(struct sigaction));
  sigemptyset(&act.sa_mask);
  act.sa_flags = 0;

  //  Install handler:
  act.sa_handler = SIG_IGN;// Ignore SIGINT
  sigaction(SIGINT,&act,NULL);

  while  (1)
  {
    printf("You can't stop me!  Ngyeah-ngyeah!\n");
    sleep(2);
  }

  return(EXIT_SUCCESS);
}
