#include	<stdlib.h>
#include	<stdio.h>
#include	<signal.h>
#include	<string.h>

void	simpleHandler	(int	sigNum)
{
  const	char*	cPtr;

  switch (rand() % 4)
  {
  case 0 : cPtr = "Ouch!";	break;
  case 1 : cPtr = "Stop that!";	break;
  case 2 : cPtr = "That hurts!";break;
  case 3 : cPtr = "Mercy!";	break;
  }
  printf("%s\n",cPtr);
}


int	main	()
{
  // Set up struct to specify the new action.
  struct sigaction act;

  //  Set member vars to zero:
  memset(&act,'\0',sizeof(struct sigaction));
  sigemptyset(&act.sa_mask);
  act.sa_flags = 0;

  //  Install handler:
  int i;
  for  (i = 1;  i <= 31;  i++)
  {
    act.sa_handler = SIG_IGN;
    sigaction(i,&act,NULL);
  }
  act.sa_handler = simpleHandler;
  sigaction(SIGINT,&act,NULL);

  while  (1)
  {
    printf("You can't stop me!  Ngyeah-ngyeah!\n");
    sleep(2);
  }

  return(EXIT_SUCCESS);
}
