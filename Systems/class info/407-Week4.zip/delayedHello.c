#include	<stdlib.h>
#include	<stdio.h>

int	main	()
{
  sleep(3);
  printf("Hello!\n");
  return(EXIT_SUCCESS);
}
