#include	<stdlib.h>
#include	<stdio.h>
#include	<signal.h>
#include	<string.h>

void signalHandler
	(int sig, siginfo_t* infoPtr, void* dataPtr)
{

  if  (infoPtr->si_pid == getppid())
    printf("Hee hee, that tickles!\n");
  else
    printf("Um, do I know you?\n");
}

int	main	()
{
  pid_t	pid = fork();

  if  (pid == 0)
  {
    struct sigaction sa;

    memset(&sa,'\0',sizeof(struct sigaction));
    sigemptyset(&sa.sa_mask );
    sa.sa_flags= SA_SIGINFO //Install sa_sigaction
			    // (as opposed to
			    // sa_handler)
	       | SA_RESTART;//If interrupted in
			    // sys call then
			    // restart sys call
			    // after signal handler
    sa.sa_sigaction = signalHandler;
    sigaction(SIGINT, &sa, NULL);

    printf("The child's id is %d\n",getpid());

    while  (1)
      sleep(1);

  }

  int	i;
  char	line[10];

  for  (i = 0; i < 4;  i++)
  {
    printf("Press enter to tickle the child:");
    fgets(line,10,stdin);
    kill(pid,SIGINT);
  }

  return(EXIT_SUCCESS);
}
