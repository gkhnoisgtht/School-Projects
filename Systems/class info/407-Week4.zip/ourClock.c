#include	<stdlib.h>
#include	<stdio.h>
#include	<signal.h>
#include	<string.h>
#include	<unistd.h>

int	shouldStillRun	= 1;

char	line[10];

void	alarmHandler	(int	sig)
{
  shouldStillRun	= 0;
}

void	ctrlCHandler	(int	sig)
{
  int	secs	= alarm(0);

  printf("%d seconds remain -- press enter to continue:\n",secs);
  fgets(line,10,stdin);
  alarm(secs);
}


int	main	()
{

  printf("How many seconds do you want to wait? ");
  fgets(line,10,stdin);
  int	waitTime	= strtol(line,NULL,10);

  // Set up struct to specify the new action.
  struct sigaction act;

  memset(&act,'\0',sizeof(struct sigaction));
  sigemptyset(&act.sa_mask);
  act.sa_flags = 0;

  act.sa_handler = alarmHandler;
  sigaction(SIGALRM,&act,NULL);

  act.sa_handler = ctrlCHandler;
  sigaction(SIGINT,&act,NULL);

  alarm(waitTime);

  while  (shouldStillRun)
    printf("Tick-tock\n");

  printf("Ding! Ding! Ding!");
  return(EXIT_SUCCESS);
}
