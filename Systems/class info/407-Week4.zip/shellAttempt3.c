#include	<stdlib.h>
#include	<stdio.h>
#include	<string.h>
#include	<unistd.h>
#include	<wait.h>

#define		LINE_LEN	64

void	childHandler	(int	sigNum)
{
  int status;

  while  (waitpid(-1,&status,WNOHANG) > 0)
    if  ( WIFEXITED(status) )
      printf("Child ended properly and returned %d\n",WEXITSTATUS(status));
    else
      printf("Child crashed\n");
}

int	main	()
{
  char	line[LINE_LEN];

  // Defines sigaction
  struct sigaction act;

  // Zero act
  memset(&act,'\0',sizeof(struct sigaction));
  sigemptyset(&act.sa_mask);
  act.sa_flags = SA_NOCLDSTOP | SA_RESTART;
  printf("sa_flags = %X\n",act.sa_flags);

  // Define action:
  act.sa_handler	= childHandler;
  sigaction(SIGCHLD,&act,NULL);

  while  (1)
  {
    printf("Waddya want!? ");
    fgets(line,LINE_LEN,stdin);
    char* cPtr = strchr(line,'\n');

    if  (cPtr != NULL)
      *cPtr = '\0';

    pid_t child = fork();

    if  (child == 0)
    {
      execl(line,line,NULL);
      fprintf(stderr,"I could not find %s\n",line);
      exit(EXIT_FAILURE);
    }

  }


  printf("Thanks Junior!\n");
  return(EXIT_SUCCESS);
}
