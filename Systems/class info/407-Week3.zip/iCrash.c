int	main()
{
  int*	iPtr = 0;

  (*iPtr)++;
}
